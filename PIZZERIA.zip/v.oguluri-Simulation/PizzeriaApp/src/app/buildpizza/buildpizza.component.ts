import { Component } from '@angular/core';
import { BuildOrderService } from '../build-order.service';
@Component({
  selector: 'app-buildpizza',
  templateUrl: './buildpizza.component.html',
  styleUrls: ['./buildpizza.component.css']
})
export class BuildpizzaComponent {
ingredients:any;
constructor(private bo:BuildOrderService){}
ngOnInit(){
  this.bo.buildpizza().subscribe(data=>{
    this.ingredients=data;
  })
}
totalcost = 0;
result:any;
selectedItems: string[] = [];

  updateTotalCost(event: any, item: any) {
    if (event.target.checked) {
      this.totalcost += item.price;
      this.selectedItems.push(item.tname);
    } else {
      this.totalcost -= item.price;
      const index = this.selectedItems.indexOf(item.tname);
      if (index > -1) {
        this.selectedItems.splice(index, 1);
      }
    }
  }

  build(){
    this.bo.customise(this.selectedItems,this.totalcost).subscribe((data)=>{
      console.log(data);
      if(data)
          alert("Ingredients added Successfully");
      else
         alert("Please Select the Pizza First");
    })
    
  }
}
