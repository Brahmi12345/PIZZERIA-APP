import { Component } from '@angular/core';
import { BuildOrderService } from '../build-order.service';
@Component({
  selector: 'app-orderpizza',
  templateUrl: './orderpizza.component.html',
  styleUrls: ['./orderpizza.component.css']
})
export class OrderpizzaComponent {
  orders:any;
  image:string="";
  price:string="";
  name:string="";
 
  constructor(private bo:BuildOrderService){}
  ngOnInit(){
    this.bo.getMenu().subscribe(data=>{
      this.orders=data;
    })
  }
  
  addtocart(order:any){
      this.bo.shopping(order.name,order.image,order.price).subscribe(data=>{
        console.log("added")
        alert("Pizza added to cart successfully");
        
  })
}

   
  }
