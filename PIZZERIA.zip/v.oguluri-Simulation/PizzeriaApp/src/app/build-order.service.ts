import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'; 
//import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class BuildOrderService {

  constructor(private http:HttpClient) { }
  getMenu(){
    return this.http.get("http://localhost:7000/pizzas");
  }
  buildpizza(){
    return this.http.get("http://localhost:7001/ingredients");
  }
  shopping(name:string,image:string,price:string){
    // //http://localhost:7000/register?empno=9000&empname=Afraim&age=23&salary=900000
    return this.http.get("http://localhost:7002/addtocart?name="+name+"&image="+image+"&price="+price);
  }
  
  getitems(){
    return this.http.get("http://localhost:7002/getitems");
  }

  deleteitem(name:string){
    return this.http.get("http://localhost:7002/deleteitem?name="+name);
  }

  increment(name:string,price:string,quantity:string){
    return this.http.get("http://localhost:7002/increment?name="+name+"&price="+price+"&quantity="+quantity);
  }

  decrement(name:string,price:string,quantity:string){
    return this.http.get("http://localhost:7002/decrement?name="+name+"&price="+price+"&quantity="+quantity);
  }

  customise(items:String[],totalcost:number)
  {
    return this.http.get("http://localhost:7002/customisepizza?items="+items+"&totalcost="+totalcost);
  }

  

}
