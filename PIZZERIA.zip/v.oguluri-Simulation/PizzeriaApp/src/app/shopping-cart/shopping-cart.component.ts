import { Component } from '@angular/core';
import { BuildOrderService } from '../build-order.service';
@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css']
})
export class ShoppingCartComponent {
 cartitems:any;
 constructor(private bo:BuildOrderService){}

 ngOnInit(){
  this.bo.getitems().subscribe((data=>{
    this.cartitems=data;
  }))
 }
 removeitem(cart:any){
  this.bo.deleteitem(cart.name).subscribe((()=>{
    this.ngOnInit();
    //alert("Item deleted Successfully");
  }))
}

plusone(item:any){
  this.bo.increment(item.name,item.price,item.quantity).subscribe(()=>{
    this.ngOnInit();
  })
}

minusone(item:any){
  this.bo.decrement(item.name,item.price,item.quantity).subscribe(()=>{
    this.ngOnInit();
  })
}
}
