let express=require('express');
let cors=require('cors');
let mongoose=require('mongoose');
let app=express();
app.use(cors());
let myschema=mongoose.Schema;
let pizzaschema=new myschema({
   "id":String,
   "type":String,
   "price":String,
   "name":String,
   "image":String,
   "description":String,
   "ingredients":[String],
   "topping":[String]
})

let pizza=mongoose.model('pizzas',pizzaschema);
app.get('/pizzas',(req,res)=>{
 
    mongoose.connect("mongodb://127.0.0.1:27017/PIZZARIADB")
    .then((connobj)=>{
   console.log("Connection Successfull")
   pizza.find()
   .then((data)=>{
      console.log("Data Retrieved successfully");
      console.log(data);
      res.json(data);
   })
   .catch((err)=>{
    console.log("data Is not retrived");
   })
})
.catch((error)=>{
  console.log("Error while Connecting to database");
  console.log(error);
})
})



app.listen(7000,()=>{
    console.log("Server Running under port number 7000");
})

module.exports = pizza;
