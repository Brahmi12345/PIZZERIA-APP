let express=require('express');
let mongoose=require('mongoose');
let cors=require('cors');
 
let app=express();
app.use(cors());
 
let schema=mongoose.Schema;
 
let ingredientschema=new schema({
    "id":Number,
    "tname":String,
    "price":Number,
    "image":String
});
 
let ingredient=mongoose.model('Ingredients',ingredientschema);
 
app.get('/ingredients',(req,res)=>{
    mongoose.connect("mongodb://127.0.0.1:27017/PIZZARIADB")
        .then((success)=>{
            console.log("Database Connection Successful");
            ingredient.find()
                .then((data)=>{
                    console.log("Ingredients data fetched successfully");
                    res.json(data);
                })
                .catch((err)=>{
                    console.log("Error while fetching ingredients data",err);
                })
        })
        .catch((err)=>{
            console.log("Error while connecting to database",err);
        })
});
 
 
app.listen(7001,()=>{
    console.log("Express server running on port 7001");
});
