let express=require('express');
let mongoose=require('mongoose');
let cors=require('cors');
let app=express();
app.use(cors());
const pizza = require('./pizzaschema');
let myschema=mongoose.Schema;

let shoppingSchema=new myschema({
    name:String,
    image:String,
    price:String,
    quantity:String,
    ingredients:[String]
});

let cart=mongoose.model('shoppingcart',shoppingSchema);
mongoose.connect("mongodb://127.0.0.1:27017/PIZZARIADB")
.then((connobj)=>{
    console.log("Connection successfull...")
})
.catch((error)=>{
    console.log("Error while Connecting to database",error);
})

//========================================================================
app.get('/addtocart',(req,res)=>{
   
    cart.find({name:req.query.name}).then((data)=>{
        console.log(data);
        if(data.length==0){
            var cart1=new cart({
                "name":req.query.name,
                "image":req.query.image,
                "price":req.query.price,
                "quantity":"1",
                "ingredients":[]
            })
            console.log(cart1);
            cart1.save().
            then((success)=>{
                console.log("data Inserted successfully");
                res.json({message:"Data Inserted successfully"});
            })
            .catch((err)=>{
                console.log("Error while inserting the data",err);
            })
        }
        else{
            let quant=parseInt(data[0].quantity);
            
            cart.updateOne({name:req.query.name},{price:(parseInt(req.query.price)*(quant+1)).toString(),quantity:(quant+1).toString()})
            .then((success)=>{
                res.json({message:"data updated successfully"});
            })
            .catch((err)=>{
                  console.log("error while updating",err)
            })
        }
        
    })
    
})

//===============================================================================

app.get('/deleteitem',(req,res)=>{
    console.log(req.query.name);
    cart.deleteOne({name:req.query.name})
    .then((success)=>{
        console.log("Data Deleted Successfully");
        res.json({message:"Data Deleted Successfully"});
    })
    .catch((err)=>{
        console.log("Error",err);
    })

})
//================================================================
app.get('/getitems',(req,res)=>{
    cart.find().then((data)=>{
         res.json(data);
    })
    .catch((error)=>{
          console.log("error while fetching data",error);
    })
})
//=============================================================

app.get('/customisepizza',(req,res)=>{
    cart.findOne().sort({ _id: -1 }).exec()
    .then(lastDocument => {
      //console.log(lastDocument);
      let newIngredients = req.query.items.split(',');
      let upgradedIngredients=[...lastDocument.ingredients,...newIngredients];
      cart.updateOne({name:lastDocument.name},{ingredients:upgradedIngredients,price:(parseInt(lastDocument.price)+parseInt(req.query.totalcost)).toString()})
      .then((success)=>{
            res.json({message:"successs"})
      })
      .catch((err)=>{
           res.json({message:"err"});
      })
    })
    .catch(error => {
      console.error('Error fetching the last document:', error);
      res.send(false);
    });

})




//================================================================================================
app.get('/increment',(req,res)=>{
    let quant=parseInt(req.query.quantity);
    let cost;
    pizza.find({name:req.query.name}).then((data)=>{
        cost=data[0].price;
        console.log(cost);
        let updatedcost=parseInt(cost)+parseInt(req.query.price);
    console.log(updatedcost);
   cart.updateOne({name:req.query.name},{price:updatedcost.toString(),quantity:(quant+1).toString()})
   .then((success)=>{
    res.json({message:"data updated successfully"});
   })
   .catch((err)=>{
    console.log("error",err)
   })
    })
    
})

//=================================================================================================
app.get('/decrement',(req,res)=>{
    let quant=parseInt(req.query.quantity);
    let cost=parseInt(req.query.price);
    if(quant>1){
        pizza.find({name:req.query.name}).then((data)=>{
            cost=data[0].price;
            console.log(cost);
            let updatedcost=parseInt(req.query.price)-(parseInt(cost));  
      cart.updateOne({name:req.query.name},{price:updatedcost.toString(),quantity:(quant-1).toString()})
   .then((success)=>{
    res.json({message:"data updated successfully"});
   })
   .catch((err)=>{
    console.log("error",err)
   })
})
}
else{
    cart.deleteOne({name:req.query.name})
    .then((success)=>{
        console.log("Data Deleted Successfully");
        res.json({message:"Data Deleted Successfully"});
    })
    .catch((err)=>{
        console.log("Error",err);
    })
}
})

//===================================================================================================

app.listen(7002,()=>{
    console.log("Server listening to port number 7002");
})
