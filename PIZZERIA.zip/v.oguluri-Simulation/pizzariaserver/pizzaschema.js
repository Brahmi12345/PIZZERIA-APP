let mongoose=require('mongoose');
let myschema=mongoose.Schema;
let pizzaschema=new myschema({
   "id":String,
   "type":String,
   "price":String,
   "name":String,
   "image":String,
   "description":String,
   "ingredients":[String],
   "topping":[String]
})

let pizza=mongoose.model('pizzas',pizzaschema);
module.exports=pizza;